from django.contrib import admin

from BotGPT.models import Dialog, Message

admin.site.register(Dialog)
admin.site.register(Message)
